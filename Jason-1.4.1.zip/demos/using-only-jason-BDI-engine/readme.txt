This is a demo of how a Java program can use only the 
Jason AgentSpeak interpreter. See the FAQ for more information.

To run this demo:

1. compile the source
	javac -classpath ../../lib/jason.jar:. SimpleJasonAgent.java

2. run the Java code:
	java -classpath ../../lib/jason.jar:. SimpleJasonAgent
